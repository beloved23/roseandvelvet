 
  <!-- /.inner title Start ./-->
  <section class="inner-titlebg">
    <div class="container">
    <div class="row">
      <div class="col-lg-12 col-md-12">
        <h2>Client Reviews</h2>
      </div>
      <div>
        <div class="col-lg-9 col-md-9">
          <h5>There are many variations of passages of Lorem Ipsum available but the majority have suffered alteration in some form.</h5>
        </div>
        <div class="col-lg-3 col-md-3"><ul class="bcrumb pull-right"><li> <a href="#">Home </a></li> <li><a href="#"> Client Reviews</a></li></ul> </div>
      </div>
    </div>
	</div>
  </section>
  
  <!-- /.inner title Start ./-->
<div class="gap"></div>
  
  <div class="container">
    <div class="row">
        <div class="col-lg-12 col-md-12">
          <h2 class="main-title">Client reviews</h2>
        </div>
      </div>
  </div>
  
    <!-- /.Client Reviews Start ./-->
  <div class="client-review-bg">
  
  
  <div class="container">
  <div class="row">
<div class="col-lg-12">
  <div class="content_slider_wrapper" id="slider1">



	<div class="circle_slider_text_wrapper" id="sw0" style="display: none;">
	<!-- content for the first layer, id="sw0" -->
		<div class="content_slider_text_block_wrap">
		<!-- "content_slider_text_block_wrap" is a div class for custom content -->
			<h3>Eliza Jonsep</h3><br />
			<span>Manager <i>at</i> Pageant Beauty Palace</span><br />
			<div class="rev-text">
            <span><i class="fa fa-quote-left"></i></span>
            <p>
            Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries.
            </p>
            </div>
		</div>
	</div>



		<div class="circle_slider_text_wrapper" id="sw1" style="display: none;">
	<!-- content for the first layer, id="sw0" -->
		<div class="content_slider_text_block_wrap">
		<!-- "content_slider_text_block_wrap" is a div class for custom content -->
			<h3>Eliza Jonsep</h3><br />
			<span>Manager <i>at</i> Pageant Beauty Palace</span><br />
			<div class="rev-text">
            <span><i class="fa fa-quote-left"></i></span>
            <p>
            Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries.
            </p>
            </div>
		</div>
	</div>



	<div class="circle_slider_text_wrapper" id="sw2" style="display: none;">
	<!-- content for the first layer, id="sw0" -->
		<div class="content_slider_text_block_wrap">
		<!-- "content_slider_text_block_wrap" is a div class for custom content -->
			<h3>Eliza Jonsep</h3><br />
			<span>Manager <i>at</i> Pageant Beauty Palace</span><br />
			<div class="rev-text">
            <span><i class="fa fa-quote-left"></i></span>
            <p>
            Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries.
            </p>
            </div>
		</div>
	</div>



		<div class="circle_slider_text_wrapper" id="sw3" style="display: none;">
	<!-- content for the first layer, id="sw0" -->
		<div class="content_slider_text_block_wrap">
		<!-- "content_slider_text_block_wrap" is a div class for custom content -->
			<h3>Eliza Jonsep</h3><br />
			<span>Manager <i>at</i> Pageant Beauty Palace</span><br />
			<div class="rev-text">
            <span><i class="fa fa-quote-left"></i></span>
            <p>
            Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries.
            </p>
            </div>
		</div>
	</div>
	
		<div class="circle_slider_text_wrapper" id="sw4" style="display: none;">
	<!-- content for the first layer, id="sw0" -->
		<div class="content_slider_text_block_wrap">
		<!-- "content_slider_text_block_wrap" is a div class for custom content -->
			<h3>Eliza Jonsep</h3><br />
			<span>Manager <i>at</i> Pageant Beauty Palace</span><br />
			<div class="rev-text">
            <span><i class="fa fa-quote-left"></i></span>
            <p>
            Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries.
            </p>
            </div>
		</div>
	</div>
	
	
		<div class="circle_slider_text_wrapper" id="sw5" style="display: none;">
	<!-- content for the first layer, id="sw0" -->
		<div class="content_slider_text_block_wrap">
		<!-- "content_slider_text_block_wrap" is a div class for custom content -->
			<h3>Eliza Jonsep</h3><br />
			<span>Manager <i>at</i> Pageant Beauty Palace</span><br />
			<div class="rev-text">
            <span><i class="fa fa-quote-left"></i></span>
            <p>
            Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries.
            </p>
            </div>
		</div>
	</div>

		<div class="circle_slider_text_wrapper" id="sw6" style="display: none;">
	<!-- content for the first layer, id="sw0" -->
		<div class="content_slider_text_block_wrap">
		<!-- "content_slider_text_block_wrap" is a div class for custom content -->
			<h3>Eliza Jonsep</h3><br />
			<span>Manager <i>at</i> Pageant Beauty Palace</span><br />
			<div class="rev-text">
            <span><i class="fa fa-quote-left"></i></span>
            <p>
            Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries.
            </p>
            </div>
		</div>
	</div>
  
  
  
  
  
  
  
  
  </div>
  </div>
  </div>
  </div>
  </div>
    <!-- /.Client Reviews End ./-->
  
  
  <!-- About Logos Start -->
  <div class="container">
      <div class="row">
        <div class="col-lg-12 col-md-12">

<div class="partner-logos">
<h3>Our Partners</h3>

<ul class="logo-slider">
  <li><img src="images/pl-01.png" alt="" /></li>
  <li><img src="images/pl-02.png" alt="" /></li>
  <li><img src="images/pl-03.png" alt="" /></li>
  <li><img src="images/pl-04.png" alt="" /></li>
  <li><img src="images/pl-05.png" alt="" /></li>
  <li><img src="images/pl-06.png" alt="" /></li>
  <li><img src="images/pl-01.png" alt="" /></li>
  <li><img src="images/pl-02.png" alt="" /></li>
</ul>
          </div>
        </div>
      </div>
      </div>
      <!-- About Logos End --> 
  
  
  
  
  
  
  
  
  
  
  



<div class="gap-50"></div>

<!-- /. Footer Start ./-->
