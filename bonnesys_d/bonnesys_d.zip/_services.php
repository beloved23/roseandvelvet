
  
  <!-- /.inner title Start ./-->
  <section class="inner-titlebg">
    <div class="container">
    <div class="row">
      <div class="col-lg-12 col-md-12">
        <h2>Services</h2>
      </div>
      <div>
        <div class="col-lg-9 col-md-9">
          <h5>There are many variations of passages of Lorem Ipsum available but the majority have suffered alteration in some form.</h5>
        </div>
        <div class="col-lg-3 col-md-3">
          <ul class="bcrumb pull-right">
            <li> <a href="#">Home </a></li>
            <li><a href="#"> Services</a></li>
          </ul>
        </div>
      </div>
    </div>
	</div>
  </section>
  
  <!-- /.inner title Start ./-->
  <div class="gap"></div>
  
  <!-- /.signup Start ./-->
  
  <section class="services">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 col-md-12">
          <h2 class="main-title">Featured Services</h2>
          <h4 class="sub-title">There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form.</h4>
        </div>
      </div>
      <div class="row service-grid">
        <div class="col-sm-3">
          <ul>
            <li><span><i class="fa fa-male"></i> <i class="fa fa-female"></i></span></li>
            <li>
              <h3>Customer Satisfaction</h3>
              <p>Fusce iaculis lacinia metus id varius. Sed tristique in urna nec ullamcorper. Integer egestas accumsan elit, non pulvinar lorem pulvinar vitae.  </p>
            </li>
            <li>
              <button onClick="window.location.href='services-details.html'">Read More</button>
            </li>
          </ul>
        </div>
        <div class="col-sm-3">
          <ul>
            <li><span><i class="fa fa-user-md"></i></span></li>
            <li>
              <h3>Customer Care</h3>
              <p>Fusce iaculis lacinia metus id varius. Sed tristique in urna nec ullamcorper. Integer egestas accumsan elit, non pulvinar lorem pulvinar vitae. </p>
            </li>
            <li>
              <button onClick="window.location.href='services-details.html'">Read More</button>
            </li>
          </ul>
        </div>
        <div class="col-sm-3">
          <ul>
            <li><span><i class="fa fa-gift"></i></span></li>
            <li>
              <h3> Membership Gifts</h3>
              <p>Fusce iaculis lacinia metus id varius. Sed tristique in urna nec ullamcorper. Integer egestas accumsan elit, non pulvinar lorem pulvinar vitae. </p>
            </li>
            <li>
              <button onClick="window.location.href='services-details.html'">Read More</button>
            </li>
          </ul>
        </div>
        <div class="col-sm-3">
          <ul>
            <li><span><i class="fa fa-lightbulb-o"></i></span></li>
            <li>
              <h3>Beauty Tips</h3>
              <p>Fusce iaculis lacinia metus id varius. Sed tristique in urna nec ullamcorper. Integer egestas accumsan elit, non pulvinar lorem pulvinar vitae. </p>
            </li>
            <li>
              <button onClick="window.location.href='services-details.html'">Read More</button>
            </li>
          </ul>
        </div>
      </div>
      
      <div class="gap-35"></div>
      <div class="row">

      <div class="col-lg-6 col-md-6">
      <strong>About Our Services</strong>
      
               <div class="panel-group" id="accordion">
  <div class="panel panel-default">
    <div class="panel-heading">
      <h4 class="panel-title">
        <a data-toggle="collapse" data-parent="#accordion"  href="#collapseOne">
         Quisque viverra neque non lobortis commodo
        </a>
      </h4>
    </div>
    <div id="collapseOne" class="panel-collapse collapse in">
      <div class="panel-body">
        Pellentesque arcu orci, tempus at placerat id, elementum ac turpis. Nullam eu lacus in dui blandit lobortis. Fusce iaculis lacinia metus id varius. Sed tristique in urna nec ullamcorper. Integer egestas accumsan elit, non pulvinar lorem pulvinar vitae. Suspendisse sed enim cursus, aliquam ante ac, vulputate sem. Proin mattis elit consequat leo eleifend.

      </div>
    </div>
  </div>
  <div class="panel panel-default">
    <div class="panel-heading">
      <h4 class="panel-title">
        <a data-toggle="collapse" class="collapsed" data-parent="#accordion" href="#collapseTwo">
          Quisque viverra neque non lobortis commodo
        </a>
      </h4>
    </div>
    <div id="collapseTwo" class="panel-collapse collapse">
      <div class="panel-body">
        Pellentesque arcu orci, tempus at placerat id, elementum ac turpis. Nullam eu lacus in dui blandit lobortis. Fusce iaculis lacinia metus id varius. Sed tristique in urna nec ullamcorper. Integer egestas accumsan elit, non pulvinar lorem pulvinar vitae. Suspendisse sed enim cursus, aliquam ante ac, vulputate sem. Proin mattis elit consequat leo eleifend.
      </div>
    </div>
  </div>
  <div class="panel panel-default">
    <div class="panel-heading">
      <h4 class="panel-title">
        <a data-toggle="collapse" class="collapsed" data-parent="#accordion" href="#collapseThree">
          Quisque viverra neque non lobortis commodo
        </a>
      </h4>
    </div>
    <div id="collapseThree" class="panel-collapse collapse">
      <div class="panel-body">
        Pellentesque arcu orci, tempus at placerat id, elementum ac turpis. Nullam eu lacus in dui blandit lobortis. Fusce iaculis lacinia metus id varius. Sed tristique in urna nec ullamcorper. Integer egestas accumsan elit, non pulvinar lorem pulvinar vitae. Suspendisse sed enim cursus, aliquam ante ac, vulputate sem. Proin mattis elit consequat leo eleifend.
      </div>
    </div>
  </div>
</div>
      
      
      </div>
      
      
      <div class="col-lg-6 col-md-6">
      
            <strong>Other Features</strong>

      
      
   <p>   Pellentesque arcu orci, tempus at placerat id, elementum ac turpis. Nullam eu lacus in dui blandit lobortis. Fusce iaculis lacinia metus id varius. Sed tristique in urna nec ullamcorper. Integer egestas accumsan elit, non pulvinar lorem pulvinar vitae. Pellentesque arcu orci, tempus at placerat id, elementum ac turpis. Nullam eu lacus in dui blandit lobortis. Fusce iaculis lacinia metus id varius. Sed tristique in urna nec ullamcorper. Integer egestas accumsan elit, non pulvinar lorem pulvinar vitae. </p>

<ul class="flist">
<li>     Nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo.</li>
<li>     Sed malesuada libero id mattis ultrices quisque viverra neque non lobortis commodo. </li>
<li>     Duis pretium pharetra lacus quis interdum sed malesuada libero id mattis ultrices.  </li>
<li>     Quisque viverra neque non lobortis commodo Nullam eu lacus in dui blandit lobortis. </li>
<li>     Excepteur sint occaecat cupidatat non, sunt in culpa qui officia deserunt mollit anim id est.</li>

</ul>      
      </div>
      
      
    </div>
    </div>
  </section>
  <!-- /.Cart End ./-->
  
  <div class="gap"></div>
  
  <!-- /. Footer Start ./-->
