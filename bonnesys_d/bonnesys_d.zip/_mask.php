
  <!-- /.inner title Start ./-->
  <section class="inner-titlebg">
    <div class="container">
    <div class="row">
      <div class="col-lg-12 col-md-12">
        <h2>PRODUCTS</h2>
      </div>
      <div class="">
        <div class="col-lg-9 col-md-9">
          <h5>There are many variations of passages of Lorem Ipsum available but the majority have suffered alteration in some form.</h5>
        </div>
        <div class="col-lg-3 col-md-3">
          <ul class="bcrumb pull-right">
            <li> <a href="#">Home </a></li>
            <li><a href="#"> Products</a></li>
          </ul>
        </div>
      </div>
    </div>
	</div>
  </section>
  
  <!-- /.inner title Start ./-->
  <div class="gap"></div>
  
  <!-- /.Blog Start ./-->
  
  <section class="products">
    <div class="container">
      <div class="row"> 
        <!-- /.Products Left Start ./-->
        <div class="col-lg-9 col-md-9">
          <div class="pro-title">
            <h2>BiON MASK</h2>
            <p>BiON masks provide superior moisturization and effective anti-aging benefits. The essential fatty acids an lecithin contained in our masks help cell repair to begin immediately. Subsequently, cells retain water and begin to function in a more productive and protective manner.</p>
          </div>
          <div class="gallery"> 
            <!-- /.Products row start ./-->
            <div class="row"> 
              <!--Product -->
              
              <!--Product End --> 
              <!--Product -->
              
              <!--Product End --> 
              <!--Product -->
             
              <!--Product End --> 
            </div>
            <!-- /.Products row end ./-->
            
            <div class="gap-30"></div>
            
            <!-- /.Products row start ./-->
            <div class="row"> 
              <!--Product -->
              <div class="col-lg-4 col-md-4 col-sm-4 cp_load fadeInUp">
                <ul class="pro-box">
                  <li class="pro">
                    <div class="block-image"> <img class="img-responsive" src="images/hydrate-gelee-mask.jpg" alt="">
                      <div class="img-overlay-3-up pat-override"></div>
                      <div class="img-overlay-3-down pat-override"></div>
                      
                    </div>
                     </li>
                  <li>
                    <h4>Hydrating Gelee Mask</h4>
                  </li>
                  
                  
                </ul>
              </div>
              <!--Product End --> 
              <!--Product -->
              <div class="col-lg-4 col-md-4 col-sm-4 cp_load fadeInUp">
                <ul class="pro-box">
                  <li class="pro">
                    <div class="block-image"> <img class="img-responsive" src="images/nutrient-mask.jpg" alt="">
                      <div class="img-overlay-3-up pat-override"></div>
                      <div class="img-overlay-3-down pat-override"></div>
                      
                    </div>
                     </li>
                  <li>
                    <h4>Nutrient Essentials Mask</h4>
                  </li>
                  
                  
                </ul>
              </div>
              <!--Product End --> 
              <!--Product -->
              <div class="col-lg-4 col-md-4 col-sm-4 cp_load fadeInUp">
                <ul class="pro-box">
                  <li class="pro">
                    <div class="block-image"> <img class="img-responsive" src="images/softening-repair-mask.jpg" alt="">
                      <div class="img-overlay-3-up pat-override"></div>
                      <div class="img-overlay-3-down pat-override"></div>
                      
                    </div>
                     </li>
                  <li>
                    <h4>Softening Repair Mask</h4>
                  </li>
                  
                  
                </ul>
              </div>
              <!--Product End --> 
            </div>
            <!-- /.Products row end ./-->
            
            <div class="gap-30"></div>
            
            <!-- /.Products row start ./-->
            <div class="row"> 
              <!--Product -->
              
              <!--Product End --> 
              <!--Product -->
              
              <!--Product End --> 
              <!--Product -->
              
              <!--Product End --> 
            </div>
            <!-- /.Products row end ./-->
            
            <div class="gap-30"></div>
            
            <!-- /.Products row start ./-->
            <div class="row"> 
              <!--Product -->
              
              <!--Product End --> 
              <!--Product -->
              
              <!--Product End --> 
              <!--Product -->
             
              <!--Product End --> 
            </div>
            <!-- /.Products row end ./--> 
          </div>
          <div class="gap-30"></div>
          
        </div>
        <!-- /.products Left End ./--> 
        
        <!-- /.sidebar Start ./-->
        <div class="col-lg-3 col-md-3 sidebar"> 
          <!-- /.Search ./-->
          <div class="search">
            <form>
              <input name="" type="text" placeholder="Search for:">
              <button><i class="fa fa-search"></i></button>
            </form>
          </div>
          <!-- /.Search End ./--> 
          <!-- /.Services list 
          <div class="services-list"> <strong class="stitle">Latest Posts</strong>
            <ul class="slist">
              <li class="simg"><img src="images/twuser-1.jpg" alt=""></li>
              <li class="spost"> <strong>Lorem Ipsum dolar sit</strong>
                <p>Sed tristique in urna nec ullamcorper integer egestas accumsan elit.</p>
              </li>
            </ul>
            <ul class="slist">
              <li class="simg"><img src="images/fp4.jpg" alt=""></li>
              <li class="spost"> <strong>Lorem Ipsum dolar sit</strong>
                <p>Sed tristique in urna nec ullamcorper integer egestas accumsan elit.</p>
              </li>
            </ul>
            <ul class="slist">
              <li class="simg"><img src="images/twuser-3.jpg" alt="" ></li>
              <li class="spost"> <strong>Lorem Ipsum dolar sit</strong>
                <p>Sed tristique in urna nec ullamcorper integer egestas accumsan elit.</p>
              </li>
            </ul>
            <ul class="slist">
              <li class="simg"><img src="images/fp7.jpg" alt=""></li>
              <li class="spost"> <strong>Lorem Ipsum dolar sit</strong>
                <p>Sed tristique in urna nec ullamcorper integer egestas accumsan elit.</p>
              </li>
            </ul>
          </div>./-->
          <!-- /.services list end ./-->
          <div class="gap-30"></div>
          
          <!-- /.Categoris list start ./-->
          <div class="ser-cats"> <strong class="stitle">Services</strong>
            <ul>
              <li><a href="facials.html">Facial Treatments</a></li>
              <li><a href="chemical.html">Chemical Peels</a></li>
              <li><a href="body-reju.html">Body Rejuvenation Treatments</a></li>
              <li><a href="stretch-mark.html">Stretch Mark Removal</a></li>
              <li><a href="body-depig.html">Body Depigmentation</a></li>
              <li><a href="body-massage.html">Body Massages</a></li>
              <li><a href="slimming-treat.html">Slimming Treatments</a></li>
              <li><a href="spa.html">Spa Packages</a></li>
              <li><a href="sign-body-treat.html">Signature Body Treatments</a></li>
            </ul>
          </div>
          <!-- /.Categoris list End ./--> 
          
          <!-- /.Flick start 
          <div>
            <div class="gap-30"></div>
            <strong class="stitle">Flickr Images</strong>
            <ul class="lb-album">
              <li> <a href="#image-1"> <img src="images/fp1.jpg" alt="image01"> <span><i class="fa fa-search-plus"></i></span> </a>
                <div class="lb-overlay" id="image-1"> <img src="images/large/large1.gif" alt="image01" />
                  <div>
                    <p>Image Tagline Will Come here</p>
                  </div>
                  <a href="#page" class="lb-close"><i class="fa fa-times-circle"></i></a> </div>
              </li>
              <li> <a href="#image-2"> <img src="images/fp2.jpg" alt="image01"> <span><i class="fa fa-search-plus"></i></span> </a>
                <div class="lb-overlay" id="image-2"> <img src="images/large/large1.gif" alt="image01" />
                  <div>
                    <p>Image Tagline Will Come here</p>
                  </div>
                  <a href="#page" class="lb-close"><i class="fa fa-times-circle"></i></a> </div>
              </li>
              <li> <a href="#image-3"> <img src="images/fp3.jpg" alt="image01"> <span><i class="fa fa-search-plus"></i></span> </a>
                <div class="lb-overlay" id="image-3"> <img src="images/large/large1.gif" alt="image01" />
                  <div>
                    <p>Image Tagline Will Come here</p>
                  </div>
                  <a href="#page" class="lb-close"><i class="fa fa-times-circle"></i></a> </div>
              </li>
              <li> <a href="#image-4"> <img src="images/fp4.jpg" alt="image01"> <span><i class="fa fa-search-plus"></i></span> </a>
                <div class="lb-overlay" id="image-4"> <img src="images/large/large1.gif" alt="image01" />
                  <div>
                    <p>Image Tagline Will Come here</p>
                  </div>
                  <a href="#page" class="lb-close"><i class="fa fa-times-circle"></i></a> </div>
              </li>
              <li> <a href="#image-5"> <img src="images/fp5.jpg" alt="image01"> <span><i class="fa fa-search-plus"></i></span> </a>
                <div class="lb-overlay" id="image-5"> <img src="images/large/large1.gif" alt="image01" />
                  <div>
                    <p>Image Tagline Will Come here</p>
                  </div>
                  <a href="#page" class="lb-close"><i class="fa fa-times-circle"></i></a> </div>
              </li>
              <li> <a href="#image-6"> <img src="images/fp1.jpg" alt="image01"> <span><i class="fa fa-search-plus"></i></span> </a>
                <div class="lb-overlay" id="image-6"> <img src="images/large/large1.gif" alt="image01" />
                  <div>
                    <p>Image Tagline Will Come here</p>
                  </div>
                  <a href="#page" class="lb-close"><i class="fa fa-times-circle"></i></a> </div>
              </li>
              <li> <a href="#image-7"> <img src="images/fp7.jpg" alt="image01"> <span><i class="fa fa-search-plus"></i></span> </a>
                <div class="lb-overlay" id="image-7"> <img src="images/large/large1.gif" alt="image01" />
                  <div>
                    <p>Image Tagline Will Come here</p>
                  </div>
                  <a href="#page" class="lb-close"><i class="fa fa-times-circle"></i></a> </div>
              </li>
              <li> <a href="#image-8"> <img src="images/fp8.jpg" alt="image01"> <span><i class="fa fa-search-plus"></i></span> </a>
                <div class="lb-overlay" id="image-8"> <img src="images/large/large1.gif" alt="image01" />
                  <div>
                    <p>Image Tagline Will Come here</p>
                  </div>
                  <a href="#page" class="lb-close"><i class="fa fa-times-circle"></i></a> </div>
              </li>
              <li> <a href="#image-9"> <img src="images/fp9.jpg" alt="image01"> <span><i class="fa fa-search-plus"></i></span> </a>
                <div class="lb-overlay" id="image-9"> <img src="images/large/large1.gif" alt="image01" />
                  <div>
                    <p>Image Tagline Will Come here</p>
                  </div>
                  <a href="#page" class="lb-close"><i class="fa fa-times-circle"></i></a> </div>
              </li>
            </ul>
          </div>./-->
          <!-- /.Flick End ./-->
          
          <div class="gap-30"></div>
          
          <!-- /.Archive start 
          <div class="archives"> <strong class="stitle">Archives</strong>
            <ul class="office-time">
              <li>January <span>2014  (04)</span> </li>
              <li>December<span>2013  (04)</span> </li>
              <li>November <span>2013  (04)</span></li>
              <li>October <span>2013  (04)</span></li>
              <li>September <span>2013  (04)</span></li>
              <li>August <span>2013  (04)</span></li>
            </ul>
          </div>./-->
          <!-- /.Aarchive end ./-->
          
          <div class="gap-30"></div>
          
          <!-- /.Facebook start ./-->
          <div class="facebook-box"> <strong class="stitle">Facebook</strong>
            <iframe src="//www.facebook.com/plugins/likebox.php?href=http%3A%2F%2Fwww.facebook.com%2FFacebookDevelopers&amp;width&amp;height=258&amp;colorscheme=light&amp;show_faces=true&amp;header=false&amp;stream=false&amp;show_border=true&amp;appId=133982306765662" style="border:none; overflow:hidden; height:258px;"></iframe>
          </div>
          <!-- /.Facebook end ./--> 
          
        </div>
        <!-- /.sidebar End ./--> 
      </div>
    </div>
  </section>
  
  <!-- /.Blog End ./-->
  
  <div class="gap"></div>
  
  <!-- /. Footer Start ./-->