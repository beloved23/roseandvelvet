
  
  <!-- /.inner title Start ./-->
  <section class="inner-titlebg">
    <div class="container">
    <div class="row">
      <div class="col-lg-12 col-md-12">
        <h2>Services</h2>
      </div>
      <div>
        <div class="col-lg-9 col-md-9">
          <h5>There are many variations of passages of Lorem Ipsum available but the majority have suffered alteration in some form.</h5>
        </div>
        <div class="col-lg-3 col-md-3">
          <ul class="bcrumb pull-right">
            <li> <a href="#">Home </a></li>
            <li><a href="#"> Services</a></li>
          </ul>
        </div>
      </div>
    </div>
	</div>
  </section>
  
  <!-- /.inner title Start ./-->
  <div class="gap"></div>
  
  <!-- /.Services Start ./-->
  
  <section class="services-details">
  <div class="container">
    <div class="row">
      <div class="col-lg-9 col-md-9">
        <div class="row">
          <div class="col-lg-5"><img src="images/ser-details.jpg" alt=""></div>
          
          <!-- /.details ./-->
          <div class="col-lg-7"> <strong class="title"> Manicure and Pedicure</strong>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque arcu orci, tempus at placerat id, elementum ac turpis. Nullam eu lacus in dui blandit lobortis. Fusce iaculis lacinia metus id varius. Sed tristique in urna nec ullamcorper. Integer egestas accumsan elit, non pulvinar lorem pulvinar vitae. Suspendisse sed enim cursus, aliquam ante ac, vulputate sem. Proin mattis elit consequat leo eleifend, sit amet ornare elit suscipit. Nam porta congue ante a molestie.</p>
            <div class="prices"> <span class="orig-price">$350</span><span class="disc-price" > $300</span> </div>
            <ul>
              <li> <strong>Duration:</strong> 60 Mitnutes</li>
              <li><strong>Experts:</strong> Lisa Anderson, John Doe</li>
              <li> <strong>Timings:</strong> 9:00 am - 10:00 pm</li>
            </ul>
            <button onclick="window.location.href='reservation.html'">Reserve</button>

          </div>
        </div>
        <div class="gap-20"></div>
        
        <!-- Features -->
        
        <div class="row">
          <div class="col-md-12"> <strong class="title">Features</strong>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque arcu orci, tempus at placerat id, elementum ac turpis. Nullam eu lacus in dui blandit lobortis. Fusce iaculis lacinia metus id varius. Sed tristique in urna nec ullamcorper. Integer egestas accumsan elit, non pulvinar lorem pulvinar vitae. </p>
            <ul class="flist">
              <li> Nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo.</li>
              <li> Sed malesuada libero id mattis ultrices quisque viverra neque non lobortis commodo. </li>
              <li> Duis pretium pharetra lacus quis interdum sed malesuada libero id mattis ultrices. </li>
              <li> Quisque viverra neque non lobortis commodo Nullam eu lacus in dui blandit lobortis. </li>
            </ul>
          </div>
        </div>
        <!-- Features End -->
        <div class="gap-clear"></div>
        
        <!-- Services 3 start --> 
        <strong class="title1">Other Services</strong>
        <div class="row gallery">
          <div class="col-lg-4 col-md-4 col-sm-4">
           <div class="hservice">
          <ul>
            <li>
              <div class="block-image"> <img class="img-responsive" src="images/sr-1.jpg" alt="">
                <div class="img-overlay-3-up pat-override"></div>
                <div class="img-overlay-3-down pat-override"></div>
                <ol class="static-style">
                  <li class="white-rounded"><a href="services-details.html"><i class="fa fa-link"></i></a> </li>
                  <li class="hicon"> <span>$350</span> <strong>$300</strong> only </li>
                  <li class="white-rounded"><a href="images/large/large1.gif" data-rel="prettyPhoto[gallery1]"><i class="fa fa-plus"></i></a> </li>
                </ol>
              </div>
            </li>
            <li>
              <h4><a href="services-details.html">Body Massage</a></h4>
              <p>All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
            </li>
            <li>
              <button class="sbtn" onclick="window.location.href='services-details.html'">Read More</button>
            </li>
          </ul>
        </div>
          </div>
          <div class="col-lg-4 col-md-4 col-sm-4">
            <div class="hservice">
          <ul>
            <li>
              <div class="block-image"> <img class="img-responsive" src="images/sr-2.jpg" alt="">
                <div class="img-overlay-3-up pat-override"></div>
                <div class="img-overlay-3-down pat-override"></div>
                <ol class="static-style">
                  <li class="white-rounded"><a href="services-details.html"><i class="fa fa-link"></i></a> </li>
                  <li class="hicon"> <span>$350</span> <strong>$300</strong> only </li>
                  <li class="white-rounded"><a href="images/large/large1.gif" data-rel="prettyPhoto[gallery1]"><i class="fa fa-plus"></i></a> </li>
                </ol>
              </div>
            </li>
            <li>
              <h4><a href="services-details.html">Sking Care & Facial</a></h4>
              <p>All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
            </li>
            <li>
              <button class="sbtn" onclick="window.location.href='services-details.html'">Read More</button>
            </li>
          </ul>
        </div>
          </div>
          <div class="col-lg-4 col-md-4 col-sm-4">
            <div class="hservice">
          <ul>
            <li>
              <div class="block-image"> <img class="img-responsive" src="images/sr-3.jpg" alt="">
                <div class="img-overlay-3-up pat-override"></div>
                <div class="img-overlay-3-down pat-override"></div>
                <ol class="static-style">
                  <li class="white-rounded"><a href="services-details.html"><i class="fa fa-link"></i></a> </li>
                  <li class="hicon"> <span>$350</span> <strong>$300</strong> only </li>
                  <li class="white-rounded"><a href="images/large/large1.gif" data-rel="prettyPhoto[gallery1]"><i class="fa fa-plus"></i></a> </li>
                </ol>
              </div>
            </li>
            <li>
              <h4><a href="services-details.html">Spa & Relaxing</a></h4>
              <p>All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
            </li>
            <li>
             <button class="sbtn" onclick="window.location.href='services-details.html'">Read More</button>
            </li>
          </ul>
        </div>
          </div>
        </div>
        <!-- Services 3 End --> 
        
      </div>
      <!-- /.details End ./--> 
      
      <!-- /.Sidebar Start ./-->
      
      <div class="col-lg-3 col-md-3 sidebar"> 
        
        <!-- /.Search ./-->
        <div class="search">
          <form>
            <input name="" type="text" placeholder="Search for:">
            <button><i class="fa fa-search"></i></button>
          </form>
        </div>
        <!-- /.Search End ./--> 
        
        <!-- /.Services list ./-->
        <div class="services-list"> <strong class="stitle">List Of Our Services</strong>
          <ul class="slist">
            <li class="simg"><img src="images/twuser-1.jpg" alt=""></li>
            <li class="spost"> <strong>Lorem Ipsum dolar sit</strong>
              <p>Sed tristique in urna nec ullamcorper integer egestas accumsan elit.</p>
            </li>
          </ul>
          <ul class="slist">
            <li class="simg"><img src="images/fp4.jpg" alt=""></li>
            <li class="spost"> <strong>Lorem Ipsum dolar sit</strong>
              <p>Sed tristique in urna nec ullamcorper integer egestas accumsan elit.</p>
            </li>
          </ul>
          <ul class="slist">
            <li class="simg"><img src="images/twuser-3.jpg" alt="" ></li>
            <li class="spost"> <strong>Lorem Ipsum dolar sit</strong>
              <p>Sed tristique in urna nec ullamcorper integer egestas accumsan elit.</p>
            </li>
          </ul>
          <ul class="slist">
            <li class="simg"><img src="images/fp7.jpg" alt=""></li>
            <li class="spost"> <strong>Lorem Ipsum dolar sit</strong>
              <p>Sed tristique in urna nec ullamcorper integer egestas accumsan elit.</p>
            </li>
          </ul>
        </div>
        <!-- /.services list end ./-->
        
        <div class="ser-cats"> <strong class="stitle2">Categories</strong>
          <ul>
            <li><a href="#">Full Body Massage</a></li>
            <li><a href="#">Waxing</a></li>
            <li><a href="#">Manicure</a></li>
            <li><a href="#">Pedicure</a></li>
            <li><a href="#">Special Therapy</a></li>
            <li><a href="#">Full Facial</a></li>
          </ul>
        </div>
        
        
        
         <!-- /.Tags start ./-->
      
      <div class="tags">
     <strong class="stitle"> Tags</strong>
        <ul>
          <li><a href="#">Massage</a></li>
          <li><a href="#">Skin Care</a></li>
           <li><a href="#">Waxing</a></li>
          <li><a href="#">Special Therapy</a></li>
           <li><a href="#">Manicure</a></li>
          <li><a href="#">Pedicure</a></li>
           <li><a href="#">Reflexology</a></li>
        </ul>
      </div>
      
      <!-- /.Tags End ./-->
        
        
        
        
        
        
      </div>
      
      
      
      <!-- /.Sidebar End ./--> 
    </div>
  </div>
</section>
<!-- /.Services End ./-->

<div class="gap"></div>

