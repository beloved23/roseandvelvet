 
  <!-- /.inner title Start ./-->
  <section class="inner-titlebg">
    <div class="container">
    <div class="row">
      <div class="col-lg-12 col-md-12">
        <h2>Blog</h2>
      </div>
      <div>
        <div class="col-lg-9 col-md-9">
          <h5>There are many variations of passages of Lorem Ipsum available but the majority have suffered alteration in some form.</h5>
        </div>
        <div class="col-lg-3 col-md-3">
          <ul class="bcrumb pull-right">
            <li> <a href="#">Home </a></li>
            <li><a href="#"> Blog</a></li>
          </ul>
        </div>
      </div>
    </div>
    </div>
  </section>
  
  <!-- /.inner title Start ./-->
  <div class="gap"></div>
  
  <!-- /.gallery Start ./-->
  
  <section class="gallery blog blog-masanary">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 gallery col-12">
          <div id="container-blog">
            <div class="grid">
              <div class="imgholder"> 
                
                <!-- blog post start -->
                <section class=" col-lg-12 blog-post"> 
                  <!-- blog title-tags -->
                  <div class="row">
                    <div class="bpost-left"></div>
                    <div class="bpost-right post-title-tags">
                      <h2><a href="blog-details.html">Aenean sagittis diam vel enim tempus</a></h2>
                      <div class="post-tags">
                        <ul>
                          <li class="puser"><a href="#">Anderson</a></li>
                          <li  class="pcomment"><a href="#">27 Comments</a></li>
                          <li class="ptags"><a href="#">Body Massage</a></li>
                        </ul>
                      </div>
                    </div>
                  </div>
                  <!-- blog title-tags end --> 
                  
                  <!-- blog img -->
                  
                  <div class="row post-title-tags">
                    <div class="bpost-left">
                      <div class="date"><strong>24</strong>Jan</div>
                      <div class="like"><i class="fa fa-heart"></i>19</div>
                    </div>
                    <div class="bpost-right">
                      <div class="block-image"> <img class="img-responsive" src="images/bm-02.jpg" alt="">
                        <div class="img-overlay-3-up pat-override"></div>
                        <div class="img-overlay-3-down pat-override"></div>
                        <ol class="static-style">
                          <li class="white-rounded"><a href="blog-details.html"><i class="fa fa-link"></i></a> </li>
                          <li class="white-rounded"><a href="images/large/large1.gif" data-rel="prettyPhoto[gallery1]"><i class="fa fa-plus"></i></a> </li>
                        </ol>
                      </div>
                      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque arcu orci, tempus at placerat id, elementum ac turpis. Nullam eu lacus in dui blandit lobortis. Fusce iaculis lacinia metus id varius. Sed tristique in urna nec ullamcorper. Integer egestas accumsan elit, non pulvinar lorem pulvinar vitae. </p>
                      <button onclick="window.location.href='blog-details.html'">Read More</button>
                    </div>
                  </div>
                  <!-- blog img end --> 
                  
                </section>
                <!-- post End --> 
                
              </div>
            </div>
            <div class="grid">
              <div class="imgholder"> 
                
                <!-- blog post start -->
                <section class=" col-lg-12 blog-post"> 
                  <!-- blog title-tags -->
                  <div class="row">
                    <div class="bpost-left"></div>
                    <div class="bpost-right post-title-tags">
                      <h2><a href="blog-details.html">Aenean sagittis diam vel enim tempus</a></h2>
                      <div class="post-tags">
                        <ul>
                          <li class="puser"><a href="#">Anderson</a></li>
                          <li  class="pcomment"><a href="#">27 Comments</a></li>
                          <li class="ptags"><a href="#">Body Massage</a></li>
                        </ul>
                      </div>
                    </div>
                  </div>
                  <!-- blog title-tags end --> 
                  
                  <!-- blog img -->
                  
                  <div class="row post-title-tags">
                    <div class="bpost-left">
                      <div class="date"><strong>24</strong>Jan</div>
                      <div class="like"><i class="fa fa-heart"></i>19</div>
                    </div>
                    <div class="bpost-right">
                      <div class="block-image"> <img class="img-responsive" src="images/bm-01.jpg" alt="">
                        <div class="img-overlay-3-up pat-override"></div>
                        <div class="img-overlay-3-down pat-override"></div>
                        <ol class="static-style">
                          <li class="white-rounded"><a href="blog-details.html"><i class="fa fa-link"></i></a> </li>
                          <li class="white-rounded"><a href="images/large/large1.gif" data-rel="prettyPhoto[gallery1]"><i class="fa fa-plus"></i></a> </li>
                        </ol>
                      </div>
                      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque arcu orci, tempus at placerat id, elementum ac turpis. Nullam eu lacus in dui blandit lobortis. Fusce iaculis lacinia metus id varius. Sed tristique in urna nec ullamcorper. Integer egestas accumsan elit, non pulvinar lorem pulvinar vitae. </p>
                      <button onclick="window.location.href='blog-details.html'">Read More</button>
                    </div>
                  </div>
                  <!-- blog img end --> 
                  
                </section>
                <!-- post End --> 
                
              </div>
            </div>
            <div class="grid cp_load fadeInUp">
              <div class="imgholder"><!-- blog post start -->
                <section class=" col-lg-12 blog-post"> 
                  <!-- blog title-tags -->
                  <div class="row">
                    <div class="bpost-left"></div>
                    <div class="bpost-right post-title-tags">
                      <h2><a href="blog-details.html">Aenean sagittis diam vel enim tempus</a></h2>
                      <div class="post-tags">
                        <ul>
                          <li class="puser"><a href="#">Anderson</a></li>
                          <li  class="pcomment"><a href="#">27 Comments</a></li>
                          <li class="ptags"><a href="#">Body Massage</a></li>
                        </ul>
                      </div>
                    </div>
                  </div>
                  <!-- blog title-tags end --> 
                  
                  <!-- blog img -->
                  
                  <div class="row post-title-tags">
                    <div class="bpost-left">
                      <div class="date"><strong>24</strong>Jan</div>
                      <div class="like"><i class="fa fa-heart"></i>19</div>
                    </div>
                    <div class="bpost-right"> 
                    
                    <div class="block-image"> <img class="img-responsive" src="images/bm-03.jpg" alt="">
                        <div class="img-overlay-3-up pat-override"></div>
                        <div class="img-overlay-3-down pat-override"></div>
                        <ol class="static-style">
                          <li class="white-rounded"><a href="blog-details.html"><i class="fa fa-link"></i></a> </li>
                          <li class="white-rounded"><a href="images/large/large1.gif" data-rel="prettyPhoto[gallery1]"><i class="fa fa-plus"></i></a> </li>
                        </ol>
                      </div>
                    
                    
                      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque arcu orci, tempus at placerat id, elementum ac turpis. Nullam eu lacus in dui blandit lobortis. Fusce iaculis lacinia metus id varius. Sed tristique in urna nec ullamcorper. Integer egestas accumsan elit, non pulvinar lorem pulvinar vitae. </p>
                      <button onclick="window.location.href='blog-details.html'">Read More</button>
                    </div>
                  </div>
                  <!-- blog img end --> 
                  
                </section>
                <!-- post End --> </div>
            </div>
            <div class="grid cp_load fadeInUp">
              <div class="imgholder"><!-- blog post start -->
                <section class=" col-lg-12 blog-post"> 
                  <!-- blog title-tags -->
                  <div class="row">
                    <div class="bpost-left"></div>
                    <div class="bpost-right post-title-tags">
                      <h2><a href="blog-details.html">Aenean sagittis diam vel enim tempus</a></h2>
                      <div class="post-tags">
                        <ul>
                          <li class="puser"><a href="#">Anderson</a></li>
                          <li  class="pcomment"><a href="#">27 Comments</a></li>
                          <li class="ptags"><a href="#">Body Massage</a></li>
                        </ul>
                      </div>
                    </div>
                  </div>
                  <!-- blog title-tags end --> 
                  
                  <!-- blog img -->
                  
                  <div class="row post-title-tags">
                    <div class="bpost-left">
                      <div class="date"><strong>24</strong>Jan</div>
                      <div class="like"><i class="fa fa-heart"></i>19</div>
                    </div>
                    <div class="bpost-right"> 
                    
                    <div class="block-image"> <img class="img-responsive" src="images/bm-04.jpg" alt="">
                        <div class="img-overlay-3-up pat-override"></div>
                        <div class="img-overlay-3-down pat-override"></div>
                        <ol class="static-style">
                          <li class="white-rounded"><a href="blog-details.html"><i class="fa fa-link"></i></a> </li>
                          <li class="white-rounded"><a href="images/large/large1.gif" data-rel="prettyPhoto[gallery1]"><i class="fa fa-plus"></i></a> </li>
                        </ol>
                      </div>
                    
                      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque arcu orci, tempus at placerat id, elementum ac turpis. Nullam eu lacus in dui blandit lobortis. Fusce iaculis lacinia metus id varius. Sed tristique in urna nec ullamcorper. Integer egestas accumsan elit, non pulvinar lorem pulvinar vitae. </p>
                      <button onclick="window.location.href='blog-details.html'">Read More</button>
                    </div>
                  </div>
                  <!-- blog img end --> 
                  
                </section>
                <!-- post End --> </div>
            </div>
            <div class="grid cp_load fadeInUp">
              <div class="imgholder"><!-- blog post start -->
                <section class=" col-lg-12 blog-post"> 
                  <!-- blog title-tags -->
                  <div class="row">
                    <div class="bpost-left"></div>
                    <div class="bpost-right post-title-tags">
                      <h2><a href="blog-details.html">Aenean sagittis diam vel enim tempus</a></h2>
                      <div class="post-tags">
                        <ul>
                          <li class="puser"><a href="#">Anderson</a></li>
                          <li  class="pcomment"><a href="#">27 Comments</a></li>
                          <li class="ptags"><a href="#">Body Massage</a></li>
                        </ul>
                      </div>
                    </div>
                  </div>
                  <!-- blog title-tags end --> 
                  
                  <!-- blog img -->
                  
                  <div class="row post-title-tags">
                    <div class="bpost-left">
                      <div class="date"><strong>24</strong>Jan</div>
                      <div class="like"><i class="fa fa-heart"></i>19</div>
                    </div>
                    <div class="bpost-right"> 
                    
                    
                    <div class="block-image"> <img class="img-responsive" src="images/bm-05.jpg" alt="">
                        <div class="img-overlay-3-up pat-override"></div>
                        <div class="img-overlay-3-down pat-override"></div>
                        <ol class="static-style">
                          <li class="white-rounded"><a href="blog-details.html"><i class="fa fa-link"></i></a> </li>
                          <li class="white-rounded"><a href="images/large/large1.gif" data-rel="prettyPhoto[gallery1]"><i class="fa fa-plus"></i></a> </li>
                        </ol>
                      </div>
                    
                      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque arcu orci, tempus at placerat id, elementum ac turpis. Nullam eu lacus in dui blandit lobortis. Fusce iaculis lacinia metus id varius. Sed tristique in urna nec ullamcorper. Integer egestas accumsan elit, non pulvinar lorem pulvinar vitae...</p>
                      <button onclick="window.location.href='blog-details.html'">Read More</button>
                    </div>
                  </div>
                  <!-- blog img end --> 
                  
                </section>
                <!-- post End --> </div>
            </div>
            <div class="grid cp_load fadeInUp">
              <div class="imgholder"><!-- blog post start -->
                <section class=" col-lg-12 blog-post"> 
                  <!-- blog title-tags -->
                  <div class="row">
                    <div class="bpost-left"></div>
                    <div class="bpost-right post-title-tags">
                      <h2><a href="blog-details.html">Aenean sagittis diam vel enim tempus</a></h2>
                      <div class="post-tags">
                        <ul>
                          <li class="puser"><a href="#">Anderson</a></li>
                          <li  class="pcomment"><a href="#">27 Comments</a></li>
                          <li class="ptags"><a href="#">Body Massage</a></li>
                        </ul>
                      </div>
                    </div>
                  </div>
                  <!-- blog title-tags end --> 
                  
                  <!-- blog img -->
                  
                  <div class="row post-title-tags">
                    <div class="bpost-left">
                      <div class="date"><strong>24</strong>Jan</div>
                      <div class="like"><i class="fa fa-heart"></i>19</div>
                    </div>
                    <div class="bpost-right"> <div class="block-image"> <img class="img-responsive" src="images/bm-06.jpg" alt="">
                        <div class="img-overlay-3-up pat-override"></div>
                        <div class="img-overlay-3-down pat-override"></div>
                        <ol class="static-style">
                          <li class="white-rounded"><a href="blog-details.html"><i class="fa fa-link"></i></a> </li>
                          <li class="white-rounded"><a href="images/large/large1.gif" data-rel="prettyPhoto[gallery1]"><i class="fa fa-plus"></i></a> </li>
                        </ol>
                      </div>
                      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque arcu orci, tempus at placerat id, elementum ac turpis. Nullam eu lacus in dui blandit lobortis. Fusce iaculis lacinia metus id varius. Sed tristique in urna nec ullamcorper. Integer egestas accumsan elit, non pulvinar lorem pulvinar vitae...</p>
                      <button onclick="window.location.href='blog-details.html'">Read More</button>
                    </div>
                  </div>
                  <!-- blog img end --> 
                  
                </section>
                <!-- post End --> </div>
            </div>
            <div class="grid cp_load fadeInUp">
              <div class="imgholder"><!-- blog post start -->
                <section class=" col-lg-12 blog-post"> 
                  <!-- blog title-tags -->
                  <div class="row">
                    <div class="bpost-left"></div>
                    <div class="bpost-right post-title-tags">
                      <h2><a href="blog-details.html">Aenean sagittis diam vel enim tempus</a></h2>
                      <div class="post-tags">
                        <ul>
                          <li class="puser"><a href="#">Anderson</a></li>
                          <li  class="pcomment"><a href="#">27 Comments</a></li>
                          <li class="ptags"><a href="#">Body Massage</a></li>
                        </ul>
                      </div>
                    </div>
                  </div>
                  <!-- blog title-tags end --> 
                  
                  <!-- blog img -->
                  
                  <div class="row post-title-tags">
                    <div class="bpost-left">
                      <div class="date"><strong>24</strong>Jan</div>
                      <div class="like"><i class="fa fa-heart"></i>19</div>
                    </div>
                    <div class="bpost-right"> <div class="block-image"> 

                <iframe src="http://player.vimeo.com/video/71717333?title=0&amp;byline=0&amp;portrait=0" height="350"></iframe>

                      </div>
                      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque arcu orci, tempus at placerat id, elementum ac turpis. Nullam eu lacus in dui blandit lobortis. Fusce iaculis lacinia metus id varius. Sed tristique in urna nec ullamcorper. Integer egestas accumsan elit, non pulvinar lorem pulvinar vitae. </p>
                      <button onclick="window.location.href='blog-details.html'">Read More</button>
                    </div>
                  </div>
                  <!-- blog img end --> 
                  
                </section>
                <!-- post End --> </div>
            </div>
            
            
            <div class="grid cp_load fadeInUp">
              <div class="imgholder"><!-- blog post start -->
                <section class=" col-lg-12 blog-post"> 
                  <!-- blog title-tags -->
                  <div class="row">
                    <div class="bpost-left"></div>
                    <div class="bpost-right post-title-tags">
                      <h2><a href="blog-details.html">Aenean sagittis diam vel enim tempus</a></h2>
                      <div class="post-tags">
                        <ul>
                          <li class="puser"><a href="#">Anderson</a></li>
                          <li  class="pcomment"><a href="#">27 Comments</a></li>
                          <li class="ptags"><a href="#">Body Massage</a></li>
                        </ul>
                      </div>
                    </div>
                  </div>
                  <!-- blog title-tags end --> 
                  
                  <!-- blog img -->
                  
                  <div class="row post-title-tags">
                    <div class="bpost-left">
                      <div class="date"><strong>24</strong>Jan</div>
                      <div class="like"><i class="fa fa-heart"></i>19</div>
                    </div>
                    <div class="bpost-right audio"> 
                      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque arcu orci, tempus at placerat id, elementum ac turpis. Nullam eu lacus in dui blandit lobortis. Fusce iaculis lacinia metus id varius. Sed tristique in urna nec ullamcorper. Integer egestas accumsan elit, non pulvinar lorem pulvinar vitae. </p>
                      <button onclick="window.location.href='blog-details.html'">Read More</button>
                    </div>
                  </div>
                  <!-- blog img end --> 
                  
                </section>
                <!-- post End --> </div>
            </div>
            
            
            
            <div class="grid cp_load fadeInUp">
              <div class="imgholder"><!-- blog post start -->
                <section class=" col-lg-12 blog-post"> 
                  <!-- blog title-tags -->
                  <div class="row">
                    <div class="bpost-left"></div>
                    <div class="bpost-right post-title-tags">
                      <h2><a href="blog-details.html">Aenean sagittis diam vel enim tempus</a></h2>
                      <div class="post-tags">
                        <ul>
                          <li class="puser"><a href="#">Anderson</a></li>
                          <li  class="pcomment"><a href="#">27 Comments</a></li>
                          <li class="ptags"><a href="#">Body Massage</a></li>
                        </ul>
                      </div>
                    </div>
                  </div>
                  <!-- blog title-tags end --> 
                  
                  <!-- blog img -->
                  
                  <div class="row post-title-tags">
                    <div class="bpost-left">
                      <div class="date"><strong>24</strong>Jan</div>
                      <div class="like"><i class="fa fa-heart"></i>19</div>
                    </div>
                    <div class="bpost-right"> <div class="block-image"> 
                    
                    <div class="audio-bg">
                  <div class="song-cover"><img src="images/music-file.jpg" alt=""></div>
                  <div class="mplayer">
                    <div id="jquery_jplayer_1" class="jp-jplayer"></div>
                    <div class="jp-title">
                      <ul>
                        <li>Cro Magnon Man</li>
                      </ul>
                    </div>
                    <div id="jp_container_1" class="jp-audio">
                      <div class="jp-type-single">
                        <div class="jp-gui jp-interface">
                          <ul class="jp-controls">
                            <li><a href="javascript:;" class="jp-previous" tabindex="1">previous</a></li>
                            <li><a href="javascript:;" class="jp-play" tabindex="1">play</a></li>
                            <li><a href="javascript:;" class="jp-pause" tabindex="1">pause</a></li>
                            <li><a href="javascript:;" class="jp-next" tabindex="1">next</a></li>
                          </ul>
                          <div class="jp-progress">
                            <div class="jp-seek-bar">
                              <div class="jp-play-bar"></div>
                            </div>
                          </div>
                          <div class="jp-volume-bar">
                            <div class="jp-volume-bar-value"></div>
                          </div>
                          <div class="jp-time-holder">
                            <div class="jp-current-time"></div>
                            <div class="jp-duration"></div>
                            <ul class="jp-toggles">
                              <li><a href="javascript:;" class="jp-repeat" tabindex="1" title="repeat">repeat</a></li>
                              <li><a href="javascript:;" class="jp-repeat-off" tabindex="1" title="repeat off">repeat off</a></li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                    
                      </div>
                      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque arcu orci, tempus at placerat id, elementum ac turpis. Nullam eu lacus in dui blandit lobortis. Fusce iaculis lacinia metus id varius. Sed tristique in urna nec ullamcorper. Integer egestas accumsan elit, non pulvinar lorem pulvinar vitae. </p>
                      <button onclick="window.location.href='blog-details.html'">Read More</button>
                    </div>
                  </div>
                  <!-- blog img end --> 
                  
                </section>
                <!-- post End --> </div>
            </div>
            
            <!-- --> 
            
          </div>
        </div>
        <!-- /.gallery End ./--> 
      </div>
    </div>
  </section>
  <!-- /.gallery End ./-->
  
  <div class="gap"></div>
  
  <!-- /. Footer Start ./-->
  
  <section id="footer">
  
  <!-- /. Footer Bottom Bar ./-->
