<!doctype html>
<html lang="en">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="Chrunch Press">
<meta name="author" content="Chrunch Press">
<base href="http://127.0.0.1/roseandv/"/>
<meta name="google-site-verification" content="glDTiLn1FQ3vasWv9tZdWaS7xbDEgLWttpauYjyCAI8" />
<meta name="description" content="Our world class services invites you to step out of the busy world, putting yourself at the top of your to do list into a healing space where you can physically and emotionally RELAX, RENEW, AND REJUVENATE">
<meta charset="utf-8">
<meta name="keywords" content="Nigeria's spa and beauty centre,Rose and Velvet. Medspa & Hammam,Nigeria's first medical spa and laser centre,Spa and beauty,Spa in nigeria, best spa in nigeria,beauty spa in nigeria,good spa in nigeria
,affordable spa and beauty in nigeria, clean spa,body massage spa  in nigeria, spa and beauty in ikeja nigeria,affordable spa in ikeja nigeria
, acne treatment in nigeria,spa services, spa and fitness,facial treatment in nigeria,chemical peels,dermatologist in lagos skin doctor,tca lagos sunburn skin treatment,top spa in lagos,facial treatment in ikeja, affordable facial treatment">

<title>Rose and Velvet</title>
<!--[if lt IE 9]>
<script src="js/html5.js"></script>
<![endif]-->
<!-- Bootstrap core CSS -->
<link href="css/bootstrap.css" rel="stylesheet">
<!-- Add custom CSS here -->
<link href="css/color.css" rel="stylesheet">
<link href="css/styles.css" rel="stylesheet">
<link href="css/jquery.bxslider.css" rel="stylesheet">
<!-- Bx-Slider -->
<link href="css/horizontal.css" rel="stylesheet">
<link href="font-awesome/css/font-awesome.min.css" rel="stylesheet">
<link href="http://code.jquery.com/ui/1.10.4/themes/smoothness/jquery-ui.css" rel="stylesheet">
    <script>

        function playmusic(){

            var myAudio = document.getElementById("myAudio");
            myAudio.play();

        }
    </script>
</head>
<body onload="playmusic()">
<!-- /. Main Container start ./-->
<div class="wrapper home"> 
  
  <!-- /. Login start ./-->
  <div id="header-login">
    <div class="container">
      <div class="row">
        <div class="col-lg-9 col-md-9">
          <h2>Log in Your Account</h2>
          <div class="login-form">
            <input name="login" type="text" placeholder="Email / Username" size="45">
            <input name="login" type="password" placeholder="Password" size="44">
            <input name="login" type="button" value="Login" class="btn">
          </div>
        </div>
        <div class="col-lg-3 col-md-3"> <span class="cross"><a id="cross-active" class="cross-login"><i class="fa fa-times"></i></a></span>
          <button class="create-account">Create New Account</button>
<div>

    <!--<div id="654766443405198232" align="left" style="width: 100%; overflow-y: hidden;" class="wcustomhtml"><audio src="http://dddproduktionen.weebly.com/files/theme/DDDmusic.mp3" autoplay loop>
<p>Your browser does not support the audio element </p>
</audio></div>-->



</div>
 </div>

      </div>
    </div>
  </div>
  <!-- /. Login End ./--> 
  
  <!-- /. topbar start ./-->
  <div class="topbar">
    <div class="container">
      <div class="row">
        <div class="col-lg-6 col-md-6 topnav"> <a href="skin">Skin Analysis</a> | <a href="reservation">Online Booking</a> | <span onclick="aud_play_pause()"><a href="#">Stop sound</a></span> </div>
        <div class="col-lg-6 col-md-6 col-sm-12">
          <div class="social pull-left"> <a href="#" title="Facebook"><i class="fa fa-facebook-square"></i></a> <a href="#" title="Linkedin"><i class="fa fa-linkedin-square"></i></a> <a href="#" title="Gplus"><i class="fa fa-google-plus-square"></i></a> <a href="#" title="Twitter"><i class="fa fa-twitter-square"></i></a> <a href="#" title="Pinterest"><i class="fa fa-pinterest-square"></i></a> <a href="#" title="Instagram"><i class="fa fa-instagram"></i></a> <a href="#" title="Flickr"><i class="fa fa-flickr"></i></a> </div>
          <div class="hlinks pull-right">
            <ul>
            <!--  <li> <a href="cart.html"> <i class="fa fa-shopping-cart"></i> Shoping Cart</a></li>
              <li><a href="register.html">Sign up</a></li>
              <li><a id="log-active" class="login-here" on >sound</a></li>
              <li>-->
               <audio id="myAudio"
                <source src="http://r18---sn-aigllnls.googlevideo.com/videoplayback?pl=24&ipbits=0&fexp=906335%2C9406993%2C9407141%2C9407664%2C9408142%2C9408420%2C9408710%2C9409205%2C9409230%2C9413503%2C9414964%2C9415304%2C9416126%2C952626%2C952640&source=youtube&expire=1434669404&key=cms1&mime=video%2Fmp4&id=o-AO5JW4sG4qJnu9JiqCk7diqcAybEncBzPAR7B1Cux8mF&itag=22&upn=S8p98_eOf-A&dur=1777.208&sver=3&ratebypass=yes&ip=196.46.246.175&signature=3DC53586042372B39041202CA06C301F3DC25DF4.5D187EEC7A4AD24391E3B7FC7400501DC172DE7D&lmt=1398649464673534&sparams=dur,expire,id,initcwndbps,ip,ipbits,itag,lmt,mime,mm,mn,ms,mv,nh,pl,ratebypass,source,upn&title=Relaxing+Spa+Music+(9)&redirect_counter=1&req_id=9672ac11867da3ee&cms_redirect=yes&mm=30&mn=sn-aigllnls&ms=nxu&mt=1434647832&mv=m&nh=IgpwcjAzLmxocjE0KgkxMjcuMC4wLjE"
                        type='audio/mp4'>
                <source src="http://media.w3.org/2010/07/bunny/04-Death_Becomes_Fur.oga"
                        type='audio/ogg; codecs=vorbis'>
                Your user agent does not support the HTML5 Audio element.
                </audio>

                <script>

                    function aud_play_pause() {
                        var myAudio = document.getElementById("myAudio");
                        myAudio.pause();
                    }
                </script>

            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- /. topbar end ./--> 
   
  <!-- /. Header Start ./-->
  <header id="header">
    <div class="container">
      <div class="row">
        <div class="col-lg-3 col-md-3">
          <div class="logo"><a href="index.html"><img src="images/inner-logo.png" alt="Logo" title="Rose and Velvet"/></a></div>
        </div>
        <div class="col-lg-9 col-md-9"> 
          <!-- Collect the nav links, forms, and other content for toggling -->
          <div>
            <div class="navbar mm">
              <div>
<nav class="navbar navbar-default" role="navigation">
  <!-- Brand and toggle get grouped for better mobile display -->
  <div class="navbar-header">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse-1">
      <span class="sr-only">Toggle navigation</span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
    </button>
  
  </div>
                <div id="navbar-collapse-1" class="collapse navbar-collapse pull-right">
                  <ul class="nav navbar-nav">
                      <li><a href="">Home</a></li>
                      <li><a href="aboutus">About Us</a> </li>
                      
                      <!-- Classic list -->
                      <li class="dropdown"><a href="#" data-toggle="dropdown" class="dropdown-toggle">Services<b class="caret"></b></a>
                        <ul class="dropdown-menu">
                          <li> 
                            <!-- Content container to add padding -->
                            <div class="mm-content">
                              <div class="row">
                                <ul class="col-sm-4 list-unstyled">
                                  <li>
                                    <p><strong>Services</strong></p>
                                  </li>
                                  <li><a href="facials">Facials for Oily/Acneic Skin</a></li>
                                  <li><a href="chemical">Chemical Peels</a></li>
                                  <li><a href="bodyreju">Body Rejuvenation Treatments</a></li>
                                  <li><a href="stretchmark">Stretch  Mark  Removal</a></li>
                                  <li><a href="bodydepig">Body Depigmentation/Lightening</a></li>
                                  <li><a href="bodymassage">Body Massages</a></li>
                                  <li><a href="slimmingtreat">Slimming Treatments</a></li>
                                  <li><a href="signbodytreat">Signature Body Treatments</a></li>
                                  <li><a href="hammam">Hammam Treatments</a></li>
                                  <li><a href="spa">Spa Packages</a></li>
                                  
                                </ul>
                               
                              </div>
                            </div>
                          </li>
                        </ul>
                      </li>
                      
                     
                      
                      <!-- Product -->
                      <li class="dropdown"><a href="#" data-toggle="dropdown" class="dropdown-toggle">Products<b class="caret"></b></a>
                        <ul role="menu" class="dropdown-menu">
                          
                          <li><a tabindex="-1" href="acne"> BiON Acne</a></li>
                          <li><a tabindex="-1" href="cleanser">BiON Cleanser </a></li>
                          <li><a tabindex="-1" href="matureskin"> BiON Mature Skin</a></li>
                          <li><a tabindex="-1" href="mask"> BiON Mask</a></li>
                          <li><a tabindex="-1" href="moisturizer"> BiON Moisturizer</a></li><li><a tabindex="-1" href="sun"> Sun Protection</a></li>
                        </ul>
                      </li>
                      <!-- Product End --> 
                      
                      <!-- Product -->
                      <li><a href="training">TRAINING</a></li>
                      <!-- Product End --> 
                      
                      
                       <!-- Blog -->
                      <li><a href="blog">BLOG</a></li>
                      <!-- Blog End --> 
                      <!-- Contact Us -->
                      <li><a href="contact">Contact Us</a></li>
                      <!-- Contact Us End -->
                      
                    </ul>
                </div>
        </nav>
              </div>
            </div>
          </div>
          <!-- /.navbar-collapse --> 
        </div>
      </div>
    </div>
  </header>
  <!-- /. Header End ./--> 
  <!-- /. Header End ./--> 
  <!-- /. Header End ./--> 
  
  <!-- /.Slider Start ./-->
  <section class="main-slider">
<div class="slider">
      <ul class="header-slider">
        <li>
          <div class="slider-text">
            <h1>Experience Comfort</h1>
            <p>Experience a full Spa service under your own roof...</p>
          </div>
          <span><img src="images/slider01.jpg" title="Experience Comfort" alt=""></span> </li>
        <li>
          <div class="slider-text">
            <h1>Relaxing Back Massages</h1>
            <p>that will help you de-stress and relax your body and mind...</p>
          </div>
          <span><img src="images/slider02.jpg" title="Relaxing Back Massages" alt=""></span></li>
        <li>
          <div class="slider-text">
            <h1>Men's Skin Care</h1>
            <p>Designed to help treat you against all skin diseases, shave bumps and irritation</p>
          </div>
          <span><img src="images/slider03.jpg" title="Men's Skin Care" alt=""></span></li>
          <li>
          <div class="slider-text">
            <h1>Body Wrap Treatment</h1>
            <p>Designed to help tissue regeneneration activities and cell metabolism and slims and tones the body</p>
          </div>
          <span><img src="images/slider04.jpg" title="Body Wrap Treatment" alt=""></span></li>
          <li>
          <div class="slider-text">
            <h1>Moroccan Hammam</h1>
            <p>Travel back into the Ancient Relaxation rituals of the Orient</p>
          </div>
          <span><img src="images/slider06.jpg" title="Moroccan Hammam" alt=""></span></li>
          <li>
          <div class="slider-text">
            <h1>Mesotherapy by TMT</h1>
            <p>Transcutaneous Mesodermic Therapy Spectacular results without surgery, injections, discomfort or side effects</p>
          </div>
          <span><img src="images/slider07.jpg" title="Mesotherapy by TMT" alt=""></span></li>
          <li>
          <div class="slider-text">
            <h1>Chemical Peels</h1>
            <p>Achieve your dream skin with our expertise on a wide range of naturally occurring acids</p>
          </div>
          <span><img src="images/slider08.jpg" title="Chemical Peels" alt=""></span></li>
      </ul>
      <!-- /.Slider End ./--> 
    </div>
  </section>
  
  <!-- /.Slider End ./--> 
  <!-- /. Welcome Start ./-->
  <section>
    <div class="container">
      <div class="row">
        <div class="col-lg-12 col-md-12">
          <div class="welcome">
            <h2 class="main-title">About Rose & Velvet</h2>
            <p class="welcome-txt">
We are a convenient alternative to traditional retail spas, providing customized personal Skin care solutions and services to clients both in the spa and in the comfort & privacy of their home. We offer a full range of spa services, spa packages and party packages to meet the needs of all customers. We're conveniently available for bookings Seven (7) days a week.
 </p>
            <button onClick="window.location.href='aboutus'">Read More</button>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- /. Welcome end ./-->
  
  <div class="mtop1"></div>
  <div class="gap-50"></div>
  <!-- /. Services Start ./-->
  <section id="hservices">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 col-md-12">
          <h2 class="main-title">Services</h2>
          <h4 class="sub-title">Our world class services invites you to step out of the busy world, putting yourself at the top of your to do list into a healing space where you can physically and emotionally RELAX, RENEW, AND REJUVENATE</h4>
        </div>
      </div>
      <div class="row gallery">
        <div class="col-lg-4 col-md-4 col-sm-6 cp_load fadeInUp">
          <div class="hservice">
            <ul>
              <li>
                <div class="block-image"> <img class="img-responsive" src="images/services-1.jpg" alt="">
                  <div class="img-overlay-3-up pat-override"></div>
                  <div class="img-overlay-3-down pat-override"></div>
                  
                </div>
              </li>
              <li>
                <h4><a href="facials.html">FACIAL TREATMENTS</a></h4>
                
              </li>
              <li>
                <button onClick="window.location.href='facials.html'">Read More</button>
              </li>
            </ul>
          </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-6 cp_load fadeInUp">
          <div class="hservice">
            <ul>
              <li>
                <div class="block-image"> <img class="img-responsive" src="images/services-2.jpg" alt="">
                  <div class="img-overlay-3-up pat-override"></div>
                  <div class="img-overlay-3-down pat-override"></div>
                  
                </div>
              </li>
              <li>
                <h4><a href="chemical.html">Chemical Peels</a></h4>
                
              </li>
              <li>
                <button onClick="window.location.href='chemical.html'">Read More</button>
              </li>
            </ul>
          </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-6 cp_load fadeInUp">
          <div class="hservice">
            <ul>
              <li>
                <div class="block-image"> <img class="img-responsive" src="images/services-3.jpg" alt="">
                  <div class="img-overlay-3-up pat-override"></div>
                  <div class="img-overlay-3-down pat-override"></div>
                  
                </div>
              </li>
              <li>
                <h4><a href="body-reju.html">Body Rejuvenation Treatments</a></h4>
                
              </li>
              <li>
                <button onClick="window.location.href='body-reju.html'">Read More</button>
              </li>
            </ul>
          </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-6 cp_load fadeInUp">
          <div class="hservice">
            <ul>
              <li>
                <div class="block-image"> <img class="img-responsive" src="images/services-4.jpg" alt="">
                  <div class="img-overlay-3-up pat-override"></div>
                  <div class="img-overlay-3-down pat-override"></div>
                  
                </div>
              </li>
              <li>
                <h4><a href="stretch-mark.html">Stretch  Mark  Removal</a></h4>
                
              </li>
              <li>
                <button onClick="window.location.href='stretch-mark.html'">Read More</button>
              </li>
            </ul>
          </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-6 cp_load fadeInUp">
          <div class="hservice">
            <ul>
              <li>
                <div class="block-image"> <img class="img-responsive" src="images/services-5.jpg" alt="">
                  <div class="img-overlay-3-up pat-override"></div>
                  <div class="img-overlay-3-down pat-override"></div>
                  
                </div>
              </li>
              <li>
                <h4><a href="body-depig.html">Body Depigmentation/Lightening</a></h4>
                
              </li>
              <li>
                <button onClick="window.location.href='body-depig.html'">Read More</button>
              </li>
            </ul>
          </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-6 cp_load fadeInUp">
          <div class="hservice">
            <ul>
              <li>
                <div class="block-image"> <img class="img-responsive" src="images/services-6.jpg" alt="">
                  <div class="img-overlay-3-up pat-override"></div>
                  <div class="img-overlay-3-down pat-override"></div>
                  
                </div>
              </li>
              <li>
                <h4><a href="body-massage.html">Body Massages</a></h4>
                
              </li>
              <li>
                <button onClick="window.location.href='body-massage.html'">Read More</button>
              </li>
            </ul>
          </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-6 cp_load fadeInUp">
          <div class="hservice">
            <ul>
              <li>
                <div class="block-image"> <img class="img-responsive" src="images/services-7.jpg" alt="">
                  <div class="img-overlay-3-up pat-override"></div>
                  <div class="img-overlay-3-down pat-override"></div>
                  
                </div>
              </li>
              <li>
                <h4><a href="slimming-treat.html">Slimming Treatments</a></h4>
                
              </li>
              <li>
                <button onClick="window.location.href='slimming-treat.html'">Read More</button>
              </li>
            </ul>
          </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-6 cp_load fadeInUp">
          <div class="hservice">
            <ul>
              <li>
                <div class="block-image"> <img class="img-responsive" src="images/services-8.jpg" alt="">
                  <div class="img-overlay-3-up pat-override"></div>
                  <div class="img-overlay-3-down pat-override"></div>
                  
                </div>
              </li>
              <li>
                <h4><a href="spa.html">Spa Packages</a></h4>
               
              </li>
              <li>
                <button onClick="window.location.href='spa.html'">Read More</button>
              </li>
            </ul>
          </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-6 cp_load fadeInUp">
          <div class="hservice">
            <ul>
              <li>
                <div class="block-image"> <img class="img-responsive" src="images/services-9.jpg" alt="">
                  <div class="img-overlay-3-up pat-override"></div>
                  <div class="img-overlay-3-down pat-override"></div>
                  
                </div>
              </li>
              <li>
                <h4><a href="hammam.html">Hammam Treatments</a></h4>
                
              </li>
              <li>
                <button onClick="window.location.href='hammam.html'">Read More</button>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- /. Services End ./--> 
  <div class="gap"></div>
  <!-- /. Products start ./-->
  <section class="home-products gallery">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 col-md-12">
          <h2 class="main-title">Products</h2>
          <h4 class="sub-title">BiON is a USA manufactured range of products for acne, anti-aging and skin rejuvenation, which are carefully formulated to improve the health and appearance of human skin using active natural ingredients that produce specific changes within the skin.</h4>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-3 col-md-3 col-sm-6 cp_load fadeInUp">
          <ul class="pro-box">
            <li class="pro">
              <div class="block-image"> <img class="img-responsive" src="images/hpro1.jpg" alt="">
                <div class="img-overlay-3-up pat-override"></div>
                <div class="img-overlay-3-down pat-override"></div>
                <ol class="static-style">
                  
                </ol>
              </div>
               </li>
            <li>
              <h4><a href="acne.html">BiON Acne Skin Care</a></h4>
            </li>
            
            <li class="pro-footer"><a href="acne.html"><span class="price">view products</span></a>  </li>
          </ul>
        </div>
        <div class="col-lg-3 col-md-3 col-sm-6 cp_load fadeInUp">
          <ul class="pro-box">
            <li class="pro">
              <div class="block-image"> <img class="img-responsive" src="images/hpro2.jpg" alt="">
                <div class="img-overlay-3-up pat-override"></div>
                <div class="img-overlay-3-down pat-override"></div>
                <ol class="static-style">
                  
                </ol>
              </div>
               </li>
            <li>
              <h4><a href="mature-skin.html">BiON Mature Skin</a></h4>
            </li>
            
            <li class="pro-footer"><a href="mature-skin.html"><span class="price">view products</span></a>  </li>
          </ul>
        </div>
        <div class="col-lg-3 col-md-3 col-sm-6 cp_load fadeInUp">
          <ul class="pro-box">
            <li class="pro">
              <div class="block-image"> <img class="img-responsive" src="images/hpro3.jpg" alt="">
                <div class="img-overlay-3-up pat-override"></div>
                <div class="img-overlay-3-down pat-override"></div>
                <ol class="static-style">
                  
                </ol>
              </div>
               </li>
            <li>
              <h4><a href="cleanser.html">BiON Cleanser</a></h4>
            </li>
            
            <li class="pro-footer"><a href="cleanser.html"><span class="price">view products</span></a>  </li>
          </ul>
        </div>
        <div class="col-lg-3 col-md-3 col-sm-6 cp_load fadeInUp">
          <ul class="pro-box">
            <li class="pro">
              <div class="block-image"> <img class="img-responsive" src="images/hpro4.jpg" alt="">
                <div class="img-overlay-3-up pat-override"></div>
                <div class="img-overlay-3-down pat-override"></div>
                <ol class="static-style">
                  
                </ol>
              </div>
               </li>
            <li>
              <h4><a href="moisturizer.html">BiON Mosturizers</a></h4>
            </li>
            
            <li class="pro-footer"><a href="moisturizer.html"><span class="price">view products</span></a> </li>
          </ul>
        </div>
      </div>
    </div>
  </section>
  <!-- /. Products End ./--> 
  <div class="gap-50"></div>
  <!-- /. Blog Start ./-->
  <section class="blog-home">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 col-md-12">
          <h2 class="main-title">Our Blog</h2>
          <h4 class="sub-title">There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form.</h4>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-3 col-md-3 col-sm-6 cp_load fadeInUp">
          <ul class="bdata">
            <li> <a href="blog-details.html">
              <div class="block-image background-scale"><img class="img-responsive" src="images/blog-img1.jpg" alt="">
                <div class="img-overlay pat-override"></div>
              </div>
              </a>
              <div class="hpost-img"><span><img class="buser" src="images/buser1.jpg" alt=""></span> </div>
            </li>
            <li class="bp-data">
              <h4><a href="blog-details.html">Lorem Ipsum dolar sit</a></h4>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam eget eros eget nisi tempus tinccibus non velited ut eros euismod.</p>
            </li>
            <li>
              <ul class="flinks">
                <li><a href="#"><i class="fa fa-calendar"></i> 12 Dec</a></li>
                <li><a href="#"><i class="fa fa-user"></i> Anderson</a></li>
                <li><a href="#"><i class="fa fa-comments"></i> 77</a></li>
              </ul>
            </li>
          </ul>
        </div>
        <div class="col-lg-3 col-md-3 col-sm-6 cp_load fadeInUp">
          <ul class="bdata">
            <li> <a href="blog-details.html">
              <div class="block-image background-scale"> <img class="img-responsive" src="images/blog-img2.jpg" alt="">
                <div class="img-overlay pat-override"></div>
              </div>
              </a>
              <div class="hpost-img"><span><img class="buser" src="images/buser2.jpg" alt=""></span> </div>
            </li>
            <li class="bp-data">
              <h4><a href="blog-details.html">Lorem Ipsum dolar sit</a></h4>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam eget eros eget nisi tempus tinccibus non velited ut eros euismod.</p>
            </li>
            <li>
              <ul class="flinks">
                <li><a href="#"><i class="fa fa-calendar"></i> 12 Dec</a></li>
                <li><a href="#"><i class="fa fa-user"></i> Anderson</a></li>
                <li><a href="#"><i class="fa fa-comments"></i> 77</a></li>
              </ul>
            </li>
          </ul>
        </div>
        <div class="col-lg-3 col-md-3 col-sm-6 cp_load fadeInUp">
          <ul class="bdata">
            <li> <a href="blog-details.html">
              <div class="block-image background-scale"> <img class="img-responsive" src="images/blog-img3.jpg" alt="">
                <div class="img-overlay pat-override"></div>
              </div>
              </a>
              <div class="hpost-img"><span><img class="buser" src="images/buser3.jpg" alt=""></span> </div>
            </li>
            <li class="bp-data">
              <h4><a href="blog-details.html">Lorem Ipsum dolar sit</a></h4>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam eget eros eget nisi tempus tinccibus non velited ut eros euismod.</p>
            </li>
            <li>
              <ul class="flinks">
                <li><a href="#"><i class="fa fa-calendar"></i> 12 Dec</a></li>
                <li><a href="#"><i class="fa fa-user"></i> Anderson</a></li>
                <li><a href="#"><i class="fa fa-comments"></i> 77</a></li>
              </ul>
            </li>
          </ul>
        </div>
        <div class="col-lg-3 col-md-3 col-sm-6 cp_load fadeInUp">
          <ul class="bdata">
            <li> <a href="blog-details.html">
              <div class="block-image background-scale"> <img class="img-responsive" src="images/blog-img4.jpg" alt="">
                <div class="img-overlay pat-override"></div>
              </div>
              </a>
              <div class="hpost-img"><span><img class="buser" src="images/buser4.jpg" alt=""></span> </div>
            </li>
            <li class="bp-data">
              <h4><a href="blog-details.html">Lorem Ipsum dolar sit</a></h4>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam eget eros eget nisi tempus tinccibus non velited ut eros euismod.</p>
            </li>
            <li>
              <ul class="flinks">
                <li><a href="#"><i class="fa fa-calendar"></i> 12 Dec</a></li>
                <li><a href="#"><i class="fa fa-user"></i> Anderson</a></li>
                <li><a href="#"><i class="fa fa-comments"></i> 77</a></li>
              </ul>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </section>
  <!-- /. Blog End ./-->
  
  <div class="gap-50"></div>
  
  <!-- /. Staff Start ./-->
  
  <section class="staff-wrapp">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 col-md-12">
          <h2 class="main-title">Expert Staff</h2>
          <h4 class="sub-title">There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form.</h4>
        </div>
      </div>
      <div class="row">
        <div class="controls">
          <button class="btn prev"><i class="fa fa-chevron-left"></i></button>
          <button class="btn next"><i class="fa fa-chevron-right"></i></button>
        </div>
        <div class="frame" id="centered">
          <ul>
            <li><img src="images/staff-1.jpg" alt="">
              <div class="cinfo">
                <h4>John Doe</h4>
                <strong>Massage Expert</strong>
                <p>The majority have suffered alteration in some form.</p>
                <div class="team-social"> <a href="#" title="Facebook"><i class="fa fa-facebook-square"></i></a> <a href="#" title="Linkedin"><i class="fa fa-linkedin-square"></i></a> <a href="#" title="Gplus"><i class="fa fa-google-plus-square"></i></a> <a href="#" title="Twitter"><i class="fa fa-twitter-square"></i></a> </div>
              </div>
            </li>
            <li><img src="images/staff-2.jpg" alt="">
              <div class="cinfo">
                <h4>John Doe</h4>
                <strong>Massage Expert</strong>
                <p>The majority have suffered alteration in some form.</p>
                <div class="team-social"> <a href="#" title="Facebook"><i class="fa fa-facebook-square"></i></a> <a href="#" title="Linkedin"><i class="fa fa-linkedin-square"></i></a> <a href="#" title="Gplus"><i class="fa fa-google-plus-square"></i></a> <a href="#" title="Twitter"><i class="fa fa-twitter-square"></i></a> </div>
              </div>
            </li>
            <li><img src="images/staff-3.jpg" alt="">
              <div class="cinfo">
                <h4>John Doe</h4>
                <strong>Massage Expert</strong>
                <p>The majority have suffered alteration in some form.</p>
                <div class="team-social"> <a href="#" title="Facebook"><i class="fa fa-facebook-square"></i></a> <a href="#" title="Linkedin"><i class="fa fa-linkedin-square"></i></a> <a href="#" title="Gplus"><i class="fa fa-google-plus-square"></i></a> <a href="#" title="Twitter"><i class="fa fa-twitter-square"></i></a> </div>
              </div>
            </li>
            <li><img src="images/staff-4.jpg" alt="">
              <div class="cinfo">
                <h4>John Doe</h4>
                <strong>Massage Expert</strong>
                <p>The majority have suffered alteration in some form.</p>
                <div class="team-social"> <a href="#" title="Facebook"><i class="fa fa-facebook-square"></i></a> <a href="#" title="Linkedin"><i class="fa fa-linkedin-square"></i></a> <a href="#" title="Gplus"><i class="fa fa-google-plus-square"></i></a> <a href="#" title="Twitter"><i class="fa fa-twitter-square"></i></a> </div>
              </div>
            </li>
            <li><img src="images/staff-5.jpg" alt="">
              <div class="cinfo">
                <h4>John Doe</h4>
                <strong>Massage Expert</strong>
                <p>The majority have suffered alteration in some form.</p>
                <div class="team-social"> <a href="#" title="Facebook"><i class="fa fa-facebook-square"></i></a> <a href="#" title="Linkedin"><i class="fa fa-linkedin-square"></i></a> <a href="#" title="Gplus"><i class="fa fa-google-plus-square"></i></a> <a href="#" title="Twitter"><i class="fa fa-twitter-square"></i></a> </div>
              </div>
            </li>
            <li><img src="images/staff-6.jpg" alt="">
              <div class="cinfo">
                <h4>John Doe</h4>
                <strong>Massage Expert</strong>
                <p>The majority have suffered alteration in some form.</p>
                <div class="team-social"> <a href="#" title="Facebook"><i class="fa fa-facebook-square"></i></a> <a href="#" title="Linkedin"><i class="fa fa-linkedin-square"></i></a> <a href="#" title="Gplus"><i class="fa fa-google-plus-square"></i></a> <a href="#" title="Twitter"><i class="fa fa-twitter-square"></i></a> </div>
              </div>
            </li>
            <li><img src="images/staff-1.jpg" alt="">
              <div class="cinfo">
                <h4>John Doe</h4>
                <strong>Massage Expert</strong>
                <p>The majority have suffered alteration in some form.</p>
                <div class="team-social"> <a href="#" title="Facebook"><i class="fa fa-facebook-square"></i></a> <a href="#" title="Linkedin"><i class="fa fa-linkedin-square"></i></a> <a href="#" title="Gplus"><i class="fa fa-google-plus-square"></i></a> <a href="#" title="Twitter"><i class="fa fa-twitter-square"></i></a> </div>
              </div>
            </li>
            <li><img src="images/staff-2.jpg" alt="">
              <div class="cinfo">
                <h4>John Doe</h4>
                <strong>Massage Expert</strong>
                <p>The majority have suffered alteration in some form.</p>
                <div class="team-social"> <a href="#" title="Facebook"><i class="fa fa-facebook-square"></i></a> <a href="#" title="Linkedin"><i class="fa fa-linkedin-square"></i></a> <a href="#" title="Gplus"><i class="fa fa-google-plus-square"></i></a> <a href="#" title="Twitter"><i class="fa fa-twitter-square"></i></a> </div>
              </div>
            </li>
            <li><img src="images/staff-3.jpg" alt="">
              <div class="cinfo">
                <h4>John Doe</h4>
                <strong>Massage Expert</strong>
                <p>The majority have suffered alteration in some form.</p>
                <div class="team-social"> <a href="#" title="Facebook"><i class="fa fa-facebook-square"></i></a> <a href="#" title="Linkedin"><i class="fa fa-linkedin-square"></i></a> <a href="#" title="Gplus"><i class="fa fa-google-plus-square"></i></a> <a href="#" title="Twitter"><i class="fa fa-twitter-square"></i></a> </div>
              </div>
            </li>
            <li><img src="images/staff-4.jpg" alt="">
              <div class="cinfo">
                <h4>John Doe</h4>
                <strong>Massage Expert</strong>
                <p>The majority have suffered alteration in some form.</p>
                <div class="team-social"> <a href="#" title="Facebook"><i class="fa fa-facebook-square"></i></a> <a href="#" title="Linkedin"><i class="fa fa-linkedin-square"></i></a> <a href="#" title="Gplus"><i class="fa fa-google-plus-square"></i></a> <a href="#" title="Twitter"><i class="fa fa-twitter-square"></i></a> </div>
              </div>
            </li>
            <li><img src="images/staff-5.jpg" alt="">
              <div class="cinfo">
                <h4>John Doe</h4>
                <strong>Massage Expert</strong>
                <p>The majority have suffered alteration in some form.</p>
                <div class="team-social"> <a href="#" title="Facebook"><i class="fa fa-facebook-square"></i></a> <a href="#" title="Linkedin"><i class="fa fa-linkedin-square"></i></a> <a href="#" title="Gplus"><i class="fa fa-google-plus-square"></i></a> <a href="#" title="Twitter"><i class="fa fa-twitter-square"></i></a> </div>
              </div>
            </li>
            <li><img src="images/staff-6.jpg" alt="">
              <div class="cinfo">
                <h4>John Doe</h4>
                <strong>Massage Expert</strong>
                <p>The majority have suffered alteration in some form.</p>
                <div class="team-social"> <a href="#" title="Facebook"><i class="fa fa-facebook-square"></i></a> <a href="#" title="Linkedin"><i class="fa fa-linkedin-square"></i></a> <a href="#" title="Gplus"><i class="fa fa-google-plus-square"></i></a> <a href="#" title="Twitter"><i class="fa fa-twitter-square"></i></a> </div>
              </div>
            </li>
            <li><img src="images/staff-5.jpg" alt="">
              <div class="cinfo">
                <h4>John Doe</h4>
                <strong>Massage Expert</strong>
                <p>The majority have suffered alteration in some form.</p>
                <div class="team-social"> <a href="#" title="Facebook"><i class="fa fa-facebook-square"></i></a> <a href="#" title="Linkedin"><i class="fa fa-linkedin-square"></i></a> <a href="#" title="Gplus"><i class="fa fa-google-plus-square"></i></a> <a href="#" title="Twitter"><i class="fa fa-twitter-square"></i></a> </div>
              </div>
            </li>
            <li><img src="images/staff-4.jpg" alt="">
              <div class="cinfo">
                <h4>John Doe</h4>
                <strong>Massage Expert</strong>
                <p>The majority have suffered alteration in some form.</p>
                <div class="team-social"> <a href="#" title="Facebook"><i class="fa fa-facebook-square"></i></a> <a href="#" title="Linkedin"><i class="fa fa-linkedin-square"></i></a> <a href="#" title="Gplus"><i class="fa fa-google-plus-square"></i></a> <a href="#" title="Twitter"><i class="fa fa-twitter-square"></i></a> </div>
              </div>
            </li>
            <li><img src="images/staff-3.jpg" alt="">
              <div class="cinfo">
                <h4>John Doe</h4>
                <strong>Massage Expert</strong>
                <p>The majority have suffered alteration in some form.</p>
                <div class="team-social"> <a href="#" title="Facebook"><i class="fa fa-facebook-square"></i></a> <a href="#" title="Linkedin"><i class="fa fa-linkedin-square"></i></a> <a href="#" title="Gplus"><i class="fa fa-google-plus-square"></i></a> <a href="#" title="Twitter"><i class="fa fa-twitter-square"></i></a> </div>
              </div>
            </li>
          </ul>
        </div>
        <div class="scrollbar">
          <div class="handle">
            <div class="mousearea"></div>
          </div>
        </div>
      </div>
    </div>
  </section>
  
  <!-- /. Staff End ./-->
  <div class="gap"></div>
  
  <!-- /. Price Start ./-->
  
  <!-- /. Price End ./--> 
  
  <!-- /. Quotes Start ./-->
  
  
  
  <!-- /. Quotes End ./--> 
  
  <!-- /. Products start ./-->
  <div class="gap"></div>
  
  <!-- /. Products End ./-->
  <div class="gap-50"></div>
                                    
  <!-- /. Footer Start ./-->
  
<section id="footer">
  
  <!-- /. Footer Bottom Bar ./-->
  
  <section class="footer-mid">
  <div class="footer-midbg">
    <div class="container">
      <div class="row">
        <div class="col-lg-3 col-md-3 col-sm-6">
          <h3>Flickr Photos</h3>
          <ul class="lb-album">
            <li> <a href="#image-1"> <img src="images/fp1.jpg" alt="image01"> <span><i class="fa fa-search-plus"></i></span> </a>
              <div class="lb-overlay" id="image-1"> <img src="images/large/large1.gif" alt="image01" />
                <div>
                  <p>Image Tagline Will Come here</p>
                </div>
                <a href="#page" class="lb-close"><i class="fa fa-times-circle"></i></a> </div>
            </li>
            <li> <a href="#image-2"> <img src="images/fp2.jpg" alt="image01"> <span><i class="fa fa-search-plus"></i></span> </a>
              <div class="lb-overlay" id="image-2"> <img src="images/large/large1.gif" alt="image01" />
                <div>
                  <p>Image Tagline Will Come here</p>
                </div>
                <a href="#page" class="lb-close"><i class="fa fa-times-circle"></i></a> </div>
            </li>
            <li> <a href="#image-3"> <img src="images/fp3.jpg" alt="image01"> <span><i class="fa fa-search-plus"></i></span> </a>
              <div class="lb-overlay" id="image-3"> <img src="images/large/large1.gif" alt="image01" />
                <div>
                  <p>Image Tagline Will Come here</p>
                </div>
                <a href="#page" class="lb-close"><i class="fa fa-times-circle"></i></a> </div>
            </li>
            <li> <a href="#image-4"> <img src="images/fp4.jpg" alt="image01"> <span><i class="fa fa-search-plus"></i></span> </a>
              <div class="lb-overlay" id="image-4"> <img src="images/large/large1.gif" alt="image01" />
                <div>
                  <p>Image Tagline Will Come here</p>
                </div>
                <a href="#page" class="lb-close"><i class="fa fa-times-circle"></i></a> </div>
            </li>
            <li> <a href="#image-5"> <img src="images/fp5.jpg" alt="image01"> <span><i class="fa fa-search-plus"></i></span> </a>
              <div class="lb-overlay" id="image-5"> <img src="images/large/large1.gif" alt="image01" />
                <div>
                  <p>Image Tagline Will Come here</p>
                </div>
                <a href="#page" class="lb-close"><i class="fa fa-times-circle"></i></a> </div>
            </li>
            <li> <a href="#image-6"> <img src="images/fp1.jpg" alt="image01"> <span><i class="fa fa-search-plus"></i></span> </a>
              <div class="lb-overlay" id="image-6"> <img src="images/large/large1.gif" alt="image01" />
                <div>
                  <p>Image Tagline Will Come here</p>
                </div>
                <a href="#page" class="lb-close"><i class="fa fa-times-circle"></i></a> </div>
            </li>
            <li> <a href="#image-7"> <img src="images/fp7.jpg" alt="image01"> <span><i class="fa fa-search-plus"></i></span> </a>
              <div class="lb-overlay" id="image-7"> <img src="images/large/large1.gif" alt="image01" />
                <div>
                  <p>Image Tagline Will Come here</p>
                </div>
                <a href="#page" class="lb-close"><i class="fa fa-times-circle"></i></a> </div>
            </li>
            <li> <a href="#image-8"> <img src="images/fp8.jpg" alt="image01"> <span><i class="fa fa-search-plus"></i></span> </a>
              <div class="lb-overlay" id="image-8"> <img src="images/large/large1.gif" alt="image01" />
                <div>
                  <p>Image Tagline Will Come here</p>
                </div>
                <a href="#page" class="lb-close"><i class="fa fa-times-circle"></i></a> </div>
            </li>
            <li> <a href="#image-9"> <img src="images/fp9.jpg" alt="image01"> <span><i class="fa fa-search-plus"></i></span> </a>
              <div class="lb-overlay" id="image-9"> <img src="images/large/large1.gif" alt="image01" />
                <div>
                  <p>Image Tagline Will Come here</p>
                </div>
                <a href="#page" class="lb-close"><i class="fa fa-times-circle"></i></a> </div>
            </li>
          </ul>
        </div>
       <div class="col-lg-3 col-md-3 col-sm-6">
          <h3>OPENING HOURS</h3>
          <ul class="recent-posts">              
              <li>Office Hours: Monday - Saturday (9:00am - 6:00pm)</li>
              <li>Treatment Hours: Monday - Saturday (9:00am - 6:00pm)</li>
              <li>Special Treatment: Sunday (Appointments Only)</li>              
            </ul>
        </div>
        <div class="col-lg-3 col-md-3 col-sm-6">
          <h3>Tweets</h3>
          <div>
            <ul class="tweets">
              <li class="twuser"><img src="images/twuser-1.jpg" alt=""></li>
              <li class="twpost">
                <h4><a href="#">@johndoe</a></h4>

                <p> There are many variations of passages the majority. <span class="url">themeforest.net/item/boxme-res</span> </p>
              </li>
            </ul>
            <ul class="tweets">
              <li class="twuser"><img src="images/twuser-2.jpg"  alt=""></li>
              <li class="twpost">
                <h4><a href="#">@dazy</a></h4>

                <p> There are many variations of passages the majority. <span class="url">themeforest.net/item/boxme-res</span> </p>
              </li>
            </ul>
            <ul class="tweets">
              <li class="twuser"><img src="images/twuser-3.jpg" alt="" ></li>
              <li class="twpost">
                <h4><a href="#">@lizaanderson</a></h4>
                <p> There are many variations of passages the majority. <span class="url">themeforest.net/item/boxme-res</span> </p>
              </li>
            </ul>
          </div>
        </div>
        <div class="col-lg-3 col-md-4 col-sm-6 getintouch">
          <h3>Get in Touch</h3>
          <p> when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries. </p>
          <p>Phone:+234 802 331 2137<br> +2348178866351<br>
           
            Email: <a href="mailto:info@info@roseandvelvet.com">info@roseandvelvet.com</a><br>
            <a href="#">www.relaxspapalace.com</a> </p>
          <div class="social"> <a href="#" title="Facebook"><i class="fa fa-facebook-square"></i></a> <a href="#" title="Linkedin"><i class="fa fa-linkedin-square"></i></a> <a href="#" title="Gplus"><i class="fa fa-google-plus-square"></i></a> <a href="#" title="Twitter"><i class="fa fa-twitter-square"></i></a> <a href="#" title="Pinterest"><i class="fa fa-pinterest-square"></i></a> <a href="#" title="Instagram"><i class="fa fa-instagram"></i></a> <a href="#" title="Flickr"><i class="fa fa-flickr"></i></a> </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- /. Footer Copy rights ./-->

<section class="footer-copy">
  <div class="container">
    <div class="row">
      <div class="col-lg-12"><strong>Pageant Beauty Palace</strong> &copy; 2014 All Rights Reserved, Designed &amp; Developed by: <a href="http://CrunchPress.com" title="Crunch Press" target="_blank">CrunchPress.com</a></div>
    </div>
  </div>
</section>
</section>

<!-- /. Footer End ./-->

</div>
<!-- main end -->
<!-- /. Main Container End ./--> 
<!-- JavaScript --> 
<script src="js/jquery-1.10.2.js"></script><!-- Main Jquery File --> 
<script src="js/modernizr.custom.39665.js"></script><!-- Modernizer --> 
<script src="js/bootstrap.js"></script><!-- Bootstrap --> 
<script src="js/jquery.easing.1.3.js"></script><!-- Easing --> 
<script src="js/jquery.bxslider.min.js"></script><!-- Bx Slider --> 
<script src="js/jquery.circliful.min.js"></script> 
<script>
jQuery(document).ready(function($){
$('#prog1').circliful();
$('#prog2').circliful();
$('#prog3').circliful();
$('#prog4').circliful();
});
</script>

<script src="js/underscore-min.js"></script>
<script src="js/cp_loader.js"></script>
<script src="js/jquery.prettyPhoto.js" type="text/javascript" charset="utf-8"></script><!-- Pretty Box --> 
<script src="js/jquery-scrolltofixed-min.js" type="text/javascript"></script>
<script src="js/custom.js"></script><!-- Custom -->

</body>
</html>

